package com.example.fersus.bazadanych2;

import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.database.Cursor;

/**
 * Created by Fersus on 12.12.2017.
 */

public class ZarzadzajDanymi
{
    private SQLiteDatabase db;

    public static final String TABLE_ROW_ID = "_id";
    public static final String TABLE_ROW_FNAME = "imie";
    public static final String TABLE_ROW_SNAME = "nazwisko";
    public static final String TABLE_ROW_AGE = "age";
    public static final String TABLE_ROW_PESEL = "pesel";
    public static final String TABLE_ROW_PL = "pl";

    private static final String DB_NAME = "adress_book_db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_N_AND_A = "names_and_addresses";

    private class CustomSQLiteOpenHelper extends SQLiteOpenHelper
    {
        public CustomSQLiteOpenHelper(Context context)
        {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            String newTableQueryString = "create table "
                    + TABLE_N_AND_A + " ("
                    + TABLE_ROW_ID
                    + " integer primary key autoincrement not null,"
                    + TABLE_ROW_FNAME
                    + " text not null,"
                    + TABLE_ROW_SNAME
                    + " text not null,"
                    + TABLE_ROW_AGE
                    + " text not null,"
                    + TABLE_ROW_PESEL
                    + " text not null,"
                    + TABLE_ROW_PL
                    + " text not null);";
            db.execSQL(newTableQueryString);
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {

        }
    }

    public ZarzadzajDanymi(Context context)
    {
        CustomSQLiteOpenHelper helper = new CustomSQLiteOpenHelper(context);
        db = helper.getWritableDatabase();
    }
    public void insert(String fname, String sname, String age, String pl, String pesel)
    {
        String query = "INSERT INTO " + TABLE_N_AND_A + " (" +
                TABLE_ROW_FNAME + ", " + TABLE_ROW_SNAME + ", " + TABLE_ROW_AGE + ", " + TABLE_ROW_PL + ", " + TABLE_ROW_PESEL + ") " +
                "VALUES (" +
                "'" + fname + "'" + ", " + "'" + sname + "'" + ", " + "'" + age + "'" + ", " + "'" + pl + "'" + ", " + "'" + pesel + "'" +");";
        Log.i("insert() = ",query);
        db.execSQL(query);
     }
    public void delete(String name)
    {
        String query = "DELETE FROM " + TABLE_N_AND_A +
                " WHERE " + TABLE_ROW_FNAME +
                " = '" + name + "';";
        Log.i("delete() = ",query);
        db.execSQL(query);
    }
    public Cursor selectAll()
    {
        Cursor c = db.rawQuery("SELECT *" +" from " + TABLE_N_AND_A, null);
        return c;
    }
    public Cursor searchName(String name)
    {
        String query = "SELECT " + TABLE_ROW_ID +
                ", " + TABLE_ROW_FNAME +
                ", " + TABLE_ROW_SNAME +
                ", " + TABLE_ROW_AGE +
                ", " + TABLE_ROW_PESEL +
                ", " + TABLE_ROW_PL +
                " from " +
                TABLE_N_AND_A +
                " Where " +
                TABLE_ROW_FNAME + "= '" + name + "';";
        Log.i("searchName() = ",query);
        Cursor c = db.rawQuery(query,null);
        return c;
    }
    public Cursor searchSName(String sname)
    {
        String query = "SELECT " + TABLE_ROW_ID +
                ", " + TABLE_ROW_FNAME +
                ", " + TABLE_ROW_SNAME +
                ", " + TABLE_ROW_AGE +
                ", " + TABLE_ROW_PESEL +
                ", " + TABLE_ROW_PL +
                " from " +
                TABLE_N_AND_A +
                " Where " +
                TABLE_ROW_SNAME + "= '" + sname + "';";
        Log.i("searchName() = ",query);
        Cursor c = db.rawQuery(query,null);
        return c;
    }
    public Cursor searchPlec(String plec)
    {
        String query = "SELECT " + TABLE_ROW_ID +
                ", " + TABLE_ROW_FNAME +
                ", " + TABLE_ROW_SNAME +
                ", " + TABLE_ROW_AGE +
                ", " + TABLE_ROW_PESEL +
                ", " + TABLE_ROW_PL +
                " from " +
                TABLE_N_AND_A +
                " Where " +
                TABLE_ROW_PL + "= '" + plec + "';";
        Log.i("searchName() = ",query);
        Cursor c = db.rawQuery(query,null);
        return c;
    }
}
