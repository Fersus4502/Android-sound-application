package com.example.fersus.bazadanych2;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.view.View;
import android.database.Cursor;
import android.util.Log;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.BatchUpdateException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener ,AdapterView.OnItemSelectedListener
{
    public Button btnInsert;
    public Button btnDelete;
    public Button btnSelect;
    public Button btnSearch;

    public EditText editFname;
    public EditText editAge;
    public EditText editDelete;
    public EditText editSearch;
    public EditText editSname;
    public EditText editPl;
    public EditText editPESEL;

    public Spinner listaWyboru;
    public CheckBox wybor;
    public String check="";


    ZarzadzajDanymi dm;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dm = new ZarzadzajDanymi(this);

        wybor = (CheckBox) findViewById(R.id.checkBox);
        listaWyboru = (Spinner) findViewById(R.id.spinner);

        btnInsert = (Button) findViewById(R.id.insertButton);
        btnDelete = (Button) findViewById(R.id.deleteButton);
        btnSearch = (Button) findViewById(R.id.searchButton);
        btnSelect = (Button) findViewById(R.id.selectButton);

        editFname = (EditText) findViewById(R.id.imieTextBox);
        editAge = (EditText) findViewById(R.id.wiekTextBox);
        editDelete = (EditText) findViewById(R.id.deleteTextBox);
        editSearch = (EditText) findViewById(R.id.searchTextBox);
        editSname = (EditText) findViewById(R.id.nazwiskoTextBox);
        editPl = (EditText) findViewById(R.id.plecTextBox);
        editPESEL = (EditText) findViewById(R.id.peselTextBox);

        String [] kryteria = new String[]{"Imię", "Nazwisko", "Płeć"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, kryteria);
        listaWyboru.setAdapter(adapter);

        listaWyboru.setOnItemSelectedListener(this);
        //btnSelect.setOnClickListener(this);
        //btnSearch.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnInsert.setOnClickListener(this);
        showData();
        search();

    }

    public void showData()
    {
        btnSelect.setOnClickListener(new View.OnClickListener()
                                     {
                                         @Override
                                         public void onClick(View view)
                                         {
                                             Cursor c = dm.selectAll();
                                             if (c.getCount() == 0)
                                             {
                                                 show("Error", "Brak recordów");
                                                 return;
                                             }

                                             StringBuffer buffer = new StringBuffer();
                                             while (c.moveToNext())
                                             {
                                                 buffer.append("Id :" + c.getString(0) + "\n");
                                                 buffer.append("Imie :" + c.getString(1) + "\n");
                                                 buffer.append("Nazwisko :" + c.getString(2) + "\n");
                                                 buffer.append("Wiek :" + c.getString(3) + "\n");
                                                 buffer.append("Pesel :" + c.getString(4) + "\n");
                                                 buffer.append("Płeć :" + c.getString(5) + "\n\n");
                                             }
                                             show("Dane", buffer.toString());
                                         }
                                     }
        );
    }
    public void search()
    {
        btnSearch.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View view)
                                         {
                                             Cursor  c = null;
                                             if(check =="Imię")
                                             {
                                                 c = dm.searchName(editSearch.getText().toString());
                                             }
                                             else if(check =="Nazwisko")
                                             {
                                                 c = dm.searchSName(editSearch.getText().toString());
                                             }
                                             else if(check =="Płeć")
                                             {
                                                 c = dm.searchPlec(editSearch.getText().toString());
                                             }

                                             if (c.getCount() == 0)
                                             {
                                                 show("Error", "Nic nie znaleziono");
                                                 return;
                                             }

                                             StringBuffer buffer = new StringBuffer();
                                             while(c.moveToNext())
                                             {
                                                 buffer.append("Id:"+c.getString(0)+"\n");
                                                 buffer.append("Imie:"+c.getString(1)+"\n");
                                                 buffer.append("Nazwisko:"+c.getString(2)+"\n");
                                                 buffer.append("Wiek:"+c.getString(3)+"\n");
                                                 buffer.append("Pesel:"+c.getString(4)+"\n");
                                                 buffer.append("Płeć:"+c.getString(5)+"\n\n");
                                                 if(wybor.isChecked())
                                                 {
                                                     break;
                                                 }
                                             }

                                             show("Data", buffer.toString());
                                         }
                                     }
        );
    }



    public void show(String title, String mess)
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setCancelable(true);
                builder.setTitle(title);
                builder.setMessage(mess);
                builder.show();
            }

    @Override
    public void onClick(View v)
    {
        String firstName = editFname.getText().toString();
        String secondName = editSname.getText().toString();
        String age = editAge.getText().toString();
        String pl = editPl.getText().toString();
        String pesel = editPESEL.getText().toString();

        if(firstName.equals(""))
        {
            firstName= "Losowa";
        }
        if(secondName.equals(""))
        {
            secondName= "Losowa";
        }
        if(age.equals("") || age.length()>2 || age.length()<1)
        {
            age="00";
        }
        if(pl.equals(""))
        {
            pl= "Losowa";
        }
        if(pesel.length()!=11)
        {
            pesel="00000000000";
        }
        switch (v.getId())
        {
            case R.id.insertButton:
                dm.insert(firstName,secondName,age,pl,pesel);
                break;
            //case R.id.selectButton:
              //  showData(dm.selectAll());
                //break;
            //case R.id.searchButton:
              //  showData(dm.searchName(editSearch.getText().toString()));
                //break;
            case R.id.deleteButton:
                dm.delete(editDelete.getText().toString());
                break;
        }
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        TextView text = (TextView) view;
        check = (String) text.getText();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView)
    {

    }
}
